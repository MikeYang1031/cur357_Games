var bullets;
var asteroids;
var ship;
var shipImage, bulletImage, particleImage;
var MARGIN = 20;
var start = true;
var button;
var score = 0;
var realscore = 0;

function preload(){
  bulletImage = loadImage('assets/bullet.png');
  shipImage1 = loadImage('assets/ship.png');
  shipImage2 = loadImage('assets/ship2.png')
  particleImage = loadImage('assets/boom.png');
}

function setup() {
  
  createCanvas(800, 800);
  
  ship = createSprite(width/2, height/2);
  ship.maxSpeed = 6;
  ship.friction = 0.95;
  ship.setCollider('circle', 0, 0, 15);
  //ship.debug = true;

  ship.addAnimation('default',shipImage1, shipImage2);

  asteroids = new Group();
  bullets = new Group();
  
  //number at beginning
  for(var i = 0; i<10 ; i++) {
    var ang = random(360);
    var px = width + 1000 * cos(radians(ang));
    var py = height + 1000 * sin(radians(ang));
    createAsteroid(3, px, py);
  }
  
}

function draw() {
background(255);  
  
  if(start == true){
    
    textAlign(CENTER);
    text('Move mouse to drive and fire, A & D to turn', width/2, 20);
    
    ///////////////////////////////////////
  for(var i=0; i<allSprites.length; i++) {
    var s = allSprites[i];
    if(s.position.x<-MARGIN) s.position.x = width+MARGIN;
    if(s.position.x>width+MARGIN) s.position.x = -MARGIN;
    if(s.position.y<-MARGIN) s.position.y = height+MARGIN;
    if(s.position.y>height+MARGIN) s.position.y = -MARGIN;
  }

  asteroids.overlap(bullets, asteroidHit);

  ship.velocity.x = (mouseX-ship.position.x);
  ship.velocity.y = (mouseY-ship.position.y);
  ship.overlap(asteroids,gameOver);

  if(keyDown('a'))
    ship.rotation -= 5;
  if(keyDown('d'))
    ship.rotation += 5;

  if(mouseWentDown(LEFT))
  {
    var bullet = createSprite(ship.position.x, ship.position.y);
    bullet.addImage(bulletImage);
    bullet.setSpeed(10, ship.rotation);
    bullet.life = 40;
    bullets.add(bullet); 
  }
      drawSprites(); 
    
    if(asteroids == 0){
        textSize(60);
        textStyle(BOLDITALIC);
        textAlign(CENTER);
        text('You Win !',width/2, 400);
    }

  }else{
  textSize(60);
  textStyle(BOLDITALIC);
  textAlign(CENTER);
  text('Game Over',width/2, 400);
  
  realscore = score - 10;
  textSize(20);
  text('your score is: '+ realscore,width/2,430);
    

  button = createButton('Click to Restart');
  button.position(350,450);
  button.mousePressed(restart);
 
  } 
}

function restart(){
  
  removeElements();
  background(255);
  start = true;
  score = 0;
  
  asteroids.removeSprites();
  
    //number at beginning
  for(var i = 0; i<10 ; i++) {
    var ang = random(360);
    var px = width + 1000 * cos(radians(ang));
    var py = height + 1000 * sin(radians(ang));
    createAsteroid(3, px, py);
  }
  ship.position.x = height/2;
  ship.position.y = width/2;
  
}
function gameOver(){
  start = false;
  //print("coll");
}

function createAsteroid(type, x, y) {
  var a = createSprite(x, y);
  var img = loadImage('assets/big.png');
  a.addImage(img);
  a.setSpeed(5 - (type/2), random(360));
  a.rotationSpeed = 0.5;
  a.type = type;
  score  = score +1;

  if(type == 2)
    a.scale = 0.7;
  if(type == 1)
    a.scale = 0.4;

  a.mass = 2+a.scale;
  a.setCollider('circle', 0, 0, 25);
  asteroids.add(a);
  //a.debug = true;
  return a;
}

function asteroidHit(asteroid, bullet) {
  var newType = asteroid.type-1;
  
  score = score + 1;

  if(newType>0) {
    createAsteroid(newType, asteroid.position.x, asteroid.position.y);
    createAsteroid(newType, asteroid.position.x, asteroid.position.y);
  }

  for(var i=0; i<10; i++) {
    var p = createSprite(bullet.position.x, bullet.position.y);
    p.addImage(particleImage);
    p.setSpeed(random(3, 5), random(360));
    p.friction = 2;
    p.life = 15;
  }

  bullet.remove();
  asteroid.remove();
}